// Seed-deterministic universe and stellar generator for Colonial Alliance RPG.
// Renders sector star maps and calculates orbits and planetary structures.

import { createRNG, getRandomItem, getSeededRandomValue, namesDb } from "./nameGenerator";

export const SPECTRAL_CLASSES = [
  { type: "M", color: "Red", temp: "2400-3700 K", massRange: [0.08, 0.45], freq: 76.45 },
  { type: "K", color: "Orange", temp: "3700-5200 K", massRange: [0.45, 0.80], freq: 12.09 },
  { type: "G", color: "Yellow", temp: "5200-6000 K", massRange: [0.80, 1.04], freq: 7.60 },
  { type: "F", color: "Pale", temp: "6000-7500 K", massRange: [1.04, 1.40], freq: 3.00 },
  { type: "A", color: "White", temp: "7500-10000 K", massRange: [1.40, 2.10], freq: 0.60 },
  { type: "B", color: "Blue", temp: "10000-30000 K", massRange: [2.10, 16.0], freq: 0.12 },
  { type: "O", color: "DeepBlue", temp: "30000-60000 K", massRange: [16.0, 90.0], freq: 0.04 } // Boosted slightly for gameplay variety
];

// Computes squared distance
export function getDistanceSq(x1, y1, x2, y2) {
  return (x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1);
}

function getPlanetClimate(type, rngRef) {
  if (type === "Terran Habitable") {
    const averageTempC = getSeededRandomValue(4, 24, rngRef);
    const equatorTempC = getSeededRandomValue(averageTempC + 14, averageTempC + 30, rngRef);
    const poleTempC = getSeededRandomValue(averageTempC - 28, averageTempC - 8, rngRef);
    return {
      averageTempC: Math.round(averageTempC),
      equatorTempC: Math.round(equatorTempC),
      poleTempC: Math.round(poleTempC),
      axialTiltDeg: getSeededRandomValue(10, 35, rngRef)
    };
  }

  if (["Desert", "Volcanic", "Rocky", "Barren Rocky"].includes(type)) {
    const averageTempC = getSeededRandomValue(8, 32, rngRef);
    return {
      averageTempC: Math.round(averageTempC),
      equatorTempC: Math.round(averageTempC + 12),
      poleTempC: Math.round(averageTempC - 18),
      axialTiltDeg: getSeededRandomValue(10, 35, rngRef)
    };
  }

  if (["Ice World", "Ice Giant"].includes(type)) {
    const averageTempC = getSeededRandomValue(-28, -8, rngRef);
    return {
      averageTempC: Math.round(averageTempC),
      equatorTempC: Math.round(averageTempC + 10),
      poleTempC: Math.round(averageTempC - 20),
      axialTiltDeg: getSeededRandomValue(8, 30, rngRef)
    };
  }

  return {
    averageTempC: 0,
    equatorTempC: 0,
    poleTempC: 0,
    axialTiltDeg: getSeededRandomValue(0, 30, rngRef)
  };
}

function getPlanetPhysicalProperties(type, relativeSize, rngRef) {
  if (type === "Gas Giant") {
    const equatorialDiameterKm = getSeededRandomValue(120000, 160000, rngRef);
    const tilesPerSide = Math.min(256, Math.max(64, Math.ceil(equatorialDiameterKm / 100)));
    return {
      equatorialDiameterKm: Math.round(equatorialDiameterKm),
      surfaceTileSizeKm: 100,
      surfaceTilesPerSide: tilesPerSide
    };
  }

  if (type === "Ice Giant") {
    const equatorialDiameterKm = getSeededRandomValue(60000, 100000, rngRef);
    const tilesPerSide = Math.min(256, Math.max(64, Math.ceil(equatorialDiameterKm / 100)));
    return {
      equatorialDiameterKm: Math.round(equatorialDiameterKm),
      surfaceTileSizeKm: 100,
      surfaceTilesPerSide: tilesPerSide
    };
  }

  if (type === "Terran Habitable") {
    const equatorialDiameterKm = getSeededRandomValue(12000, 16000, rngRef) * (0.94 + ((relativeSize || 8) / 20) * 0.03);
    const tilesPerSide = Math.min(256, Math.max(64, Math.ceil(equatorialDiameterKm / 100)));
    return {
      equatorialDiameterKm: Math.round(equatorialDiameterKm),
      surfaceTileSizeKm: 100,
      surfaceTilesPerSide: tilesPerSide
    };
  }

  if (["Desert", "Volcanic", "Rocky", "Barren Rocky"].includes(type)) {
    const equatorialDiameterKm = getSeededRandomValue(8000, 14000, rngRef) * (0.92 + ((relativeSize || 8) / 20) * 0.025);
    const tilesPerSide = Math.min(256, Math.max(64, Math.ceil(equatorialDiameterKm / 100)));
    return {
      equatorialDiameterKm: Math.round(equatorialDiameterKm),
      surfaceTileSizeKm: 100,
      surfaceTilesPerSide: tilesPerSide
    };
  }

  if (["Ice World"].includes(type)) {
    const equatorialDiameterKm = getSeededRandomValue(8000, 14000, rngRef);
    const tilesPerSide = Math.min(256, Math.max(64, Math.ceil(equatorialDiameterKm / 100)));
    return {
      equatorialDiameterKm: Math.round(equatorialDiameterKm),
      surfaceTileSizeKm: 100,
      surfaceTilesPerSide: tilesPerSide
    };
  }

  const equatorialDiameterKm = getSeededRandomValue(6000, 12000, rngRef);
  const tilesPerSide = Math.min(256, Math.max(64, Math.ceil(equatorialDiameterKm / 100)));
  return {
    equatorialDiameterKm: Math.round(equatorialDiameterKm),
    surfaceTileSizeKm: 100,
    surfaceTilesPerSide: tilesPerSide
  };
}

// Generate the sector universe
export function generateUniverse(config = {}) {
  const seed = config.seed !== undefined ? config.seed : 42;
  const rng = createRNG(seed);
  
  const systemCount = config.systemCount || 300;
  const mapSizeX = config.mapSizeX || 4800; // 48 dividers * 100px
  const mapSizeY = config.mapSizeY || 4800;
  const minimumHabitable = config.minimumHabitable || 14;

  const starSystems = [];
  const minDistanceSq = 120 * 120; // Prevent systems from overlapping too closely

  // Generate unique 2D coordinates for systems (Poisson-disc like verification)
  const generateCoords = () => {
    let attempts = 0;
    while (attempts < 500) {
      const x = getSeededRandomValue(200, mapSizeX - 200, rng);
      const y = getSeededRandomValue(200, mapSizeY - 200, rng);
      let farEnough = true;
      for (const sys of starSystems) {
        if (getDistanceSq(x, y, sys.x, sys.y) < minDistanceSq) {
          farEnough = false;
          break;
        }
      }
      if (farEnough) return { x, y };
      attempts++;
    }
    // Fallback if space is crowded
    return {
      x: getSeededRandomValue(200, mapSizeX - 200, rng),
      y: getSeededRandomValue(200, mapSizeY - 200, rng)
    };
  };

  // Pre-calculate class weights
  const cumulativeFreqs = [];
  let totalFreq = 0;
  SPECTRAL_CLASSES.forEach(cls => {
    totalFreq += cls.freq;
    cumulativeFreqs.push({ cls, threshold: totalFreq });
  });

  const selectSpectralClass = (forceHabitable) => {
    if (forceHabitable) {
      return rng() < 0.6 
        ? SPECTRAL_CLASSES.find(c => c.type === "G")
        : SPECTRAL_CLASSES.find(c => c.type === "F");
    }
    const val = rng() * totalFreq;
    for (const entry of cumulativeFreqs) {
      if (val <= entry.threshold) return entry.cls;
    }
    return SPECTRAL_CLASSES[0];
  };

  const getPlanetType = (spectralType, orbitalRadius, isHabPlanet, rngRef) => {
    if (isHabPlanet) return "Terran Habitable";

    const coolStar = ["M", "K"].includes(spectralType);
    const sunLike = ["G", "F"].includes(spectralType);

    if (orbitalRadius > 6.5) {
      const roll = rngRef();
      if (roll < 0.55) return "Ice Giant";
      if (roll < 0.85) return "Gas Giant";
      return "Ice World";
    }

    if (orbitalRadius > 3.2) {
      const roll = rngRef();
      if (roll < 0.45) return "Gas Giant";
      if (roll < 0.8) return "Ice Giant";
      return "Ice World";
    }

    if (sunLike) {
      const roll = rngRef();
      if (roll < 0.25) return "Volcanic";
      if (roll < 0.55) return "Barren Rocky";
      if (roll < 0.8) return "Desert";
      return "Rocky";
    }

    if (coolStar) {
      const roll = rngRef();
      if (roll < 0.35) return "Volcanic";
      if (roll < 0.65) return "Barren Rocky";
      if (roll < 0.85) return "Ice World";
      return "Desert";
    }

    const roll = rngRef();
    if (roll < 0.3) return "Volcanic";
    if (roll < 0.6) return "Barren Rocky";
    if (roll < 0.8) return "Desert";
    return "Rocky";
  };

  let habitableCreated = 0;

  for (let i = 1; i <= systemCount; i++) {
    const coords = generateCoords();
    const forceHabitable = habitableCreated < minimumHabitable;
    const spectral = selectSpectralClass(forceHabitable);
    const mass = getSeededRandomValue(spectral.massRange[0] * 100, spectral.massRange[1] * 100, rng) / 100;
    
    // Naming
    let name = `SEC_2-${String(i).padStart(4, "0")}`;
    const namePool = namesDb.namesMaster;
    if (forceHabitable && namePool && namePool.length > 0) {
      // Pick a unique name from database
      const attempts = 10;
      let pickedName = "";
      for (let k = 0; k < attempts; k++) {
        pickedName = getRandomItem(namePool, rng);
        if (!starSystems.some(s => s.name === pickedName)) {
          name = pickedName;
          break;
        }
      }
    }

    const planetChanceByType = {
      M: 0.7,
      K: 0.8,
      G: 0.9,
      F: 0.85,
      A: 0.05,
      B: 0.0,
      O: 0.0
    };

    const habitableChanceByType = {
      M: 0.03,
      K: 0.06,
      G: 0.18,
      F: 0.14,
      A: 0.0,
      B: 0.0,
      O: 0.0
    };

    const hasPlanets = forceHabitable || rng() < (planetChanceByType[spectral.type] ?? 0.25);
    let isHabitable = forceHabitable;

    if (!isHabitable && ["G", "F"].includes(spectral.type) && rng() < (habitableChanceByType[spectral.type] ?? 0.0)) {
      isHabitable = true;
    }

    const system = {
      id: `sys-${i}`,
      name,
      designation: `2_${String(i).padStart(4, "0")}`,
      x: coords.x,
      y: coords.y,
      spectralType: spectral.type,
      color: spectral.color,
      mass,
      hasPlanets,
      isHabitable,
      planets: []
    };

    if (system.hasPlanets) {
      const planetCount = getSeededRandomValue(3, 10, rng);
      const habitableIndex = isHabitable ? getSeededRandomValue(1, Math.max(1, planetCount - 1), rng) : -1;
      
      for (let p = 0; p < planetCount; p++) {
        const orbitalRadius = getSeededRandomValue(15 * (p + 1), 35 * (p + 1), rng) / 10; // in AU
        const isHabPlanet = p === habitableIndex;
        const type = getPlanetType(spectral.type, orbitalRadius, isHabPlanet, rng);

        const relativeSize = type.includes("Giant") ? getSeededRandomValue(25, 90, rng) : getSeededRandomValue(3, 12, rng);
        const physicalProperties = getPlanetPhysicalProperties(type, relativeSize, rng);

        system.planets.push({
          id: `${system.id}-p-${p}`,
          index: p + 1,
          name: `${system.name} ${String.fromCharCode(98 + p)}`, // b, c, d...
          orbitalRadius,
          type,
          hasHydrosphere: type === "Terran Habitable",
          hydrospherePercent: type === "Terran Habitable" ? getSeededRandomValue(45, 80, rng) : 0,
          size: relativeSize,
          climate: getPlanetClimate(type, rng),
          physicalProperties,
          explorationGrid: null // Seeded dynamically when explored
        });
      }

      if (forceHabitable) {
        habitableCreated++;
      }
    }

    starSystems.push(system);
  }

  // Faction Sovereignty Placement (fnc_GetSovereigntyRanges in JS)
  // 1. Calculate weights & sovereignty scores for loaded societies
  const societiesWithScores = namesDb.societies.map(soc => {
    const eco = soc.EconomyScore || 5;
    const mil = soc.MilitaryScore || 5;
    const edu = soc.EducationScore || 5;
    const lead = soc.LeadershipScore || 5;
    const pop = soc.PopulationScore || 3;
    const tech = soc.TechnologyScore || 5;
    const unity = soc.UnityScore || 5;

    const score = Math.round(
      (eco * 2) +
      (mil * 5) +
      (edu / 2) +
      (lead / 2) +
      (pop / 2) +
      tech +
      (unity / 2)
    );
    return { ...soc, sovereigntyScore: score };
  });

  // Sort societies descending by sovereignty
  societiesWithScores.sort((a, b) => b.sovereigntyScore - a.sovereigntyScore);

  const claimedSystemIds = new Set();
  const territories = [];

  // Helper to determine systems within range
  const getSystemsWithinRange = (sourceSys, range, systemsPool) => {
    const rangeSq = range * range;
    const results = [];
    for (const sys of systemsPool) {
      if (sys.id === sourceSys.id) continue;
      if (getDistanceSq(sourceSys.x, sourceSys.y, sys.x, sys.y) <= rangeSq) {
        results.push(sys);
      }
    }
    return results;
  };

  const SOVEREIGNTY_RANGE_MULTIPLIER = 8.5; // Maps score directly to pixel ranges

  societiesWithScores.forEach(faction => {
    // Find named systems with planets not already claimed
    const candidateHomeworlds = starSystems.filter(sys => {
      if (claimedSystemIds.has(sys.id)) return false;
      return sys.isHabitable; // Homeworlds must be habitable
    });

    if (candidateHomeworlds.length === 0) return;

    let bestHomeworld = null;
    let maxConnections = -1;
    let systemsInRangeOfBest = [];

    const factionRange = faction.sovereigntyScore * SOVEREIGNTY_RANGE_MULTIPLIER;

    // Search for homeworld that maximizes density of unclaimed systems in range
    candidateHomeworlds.forEach(sys => {
      const inRangeList = getSystemsWithinRange(sys, factionRange, starSystems.filter(s => !claimedSystemIds.has(s.id)));
      if (inRangeList.length > maxConnections) {
        maxConnections = inRangeList.length;
        bestHomeworld = sys;
        systemsInRangeOfBest = inRangeList;
      }
    });

    if (bestHomeworld) {
      // Claim the homeworld and all systems in range
      claimedSystemIds.add(bestHomeworld.id);
      bestHomeworld.faction = faction.FactionName;
      bestHomeworld.isHomeworld = true;

      systemsInRangeOfBest.forEach(sys => {
        claimedSystemIds.add(sys.id);
        sys.faction = faction.FactionName;
      });

      territories.push({
        factionName: faction.FactionName,
        color: getFactionColor(faction.FactionName),
        homeworldId: bestHomeworld.id,
        range: factionRange,
        systems: [bestHomeworld, ...systemsInRangeOfBest]
      });

      // Update the Faction JSON properties
      faction.homeworld = bestHomeworld.name;
      faction.xCoord = bestHomeworld.x;
      faction.yCoord = bestHomeworld.y;
    }
  });

  return {
    starSystems,
    territories,
    societies: societiesWithScores
  };
}

// Return colors for known factions
function getFactionColor(name) {
  const map = {
    "Cobalt Mercenary Coalition": "rgba(30, 144, 255, 0.4)", // Blue
    "Crimson Corsairs": "rgba(220, 20, 60, 0.4)", // Red
    "Iron Dominion": "rgba(105, 105, 105, 0.4)", // Dark Grey
    "New Jerusalem Republic": "rgba(218, 165, 32, 0.4)", // Golden
    "Puritan Ascendancy": "rgba(147, 112, 219, 0.4)", // Purple
    "Serenity Collective": "rgba(46, 139, 87, 0.4)", // Sea Green
    "Sisterhood of Gaia": "rgba(34, 139, 34, 0.4)", // Green
    "Stellar Directorate of Solitude": "rgba(112, 128, 144, 0.4)", // Slate
    "Stellar Trade Federation": "rgba(244, 164, 96, 0.4)", // Sandy
    "Technocratic Union of Nova Celestia": "rgba(0, 206, 209, 0.4)", // Turquoise
    "The Caliphate of Najm": "rgba(189, 183, 107, 0.4)", // Dark Khaki
    "Union of Celestial Nations": "rgba(178, 34, 34, 0.4)", // Firebrick
    "Unity Alliance": "rgba(70, 130, 180, 0.4)", // Steel Blue
    "Vance Consortium": "rgba(205, 133, 63, 0.4)", // Peru Brown
    "Verdant Alliance": "rgba(154, 205, 50, 0.4)" // Yellow Green
  };
  return map[name] || "rgba(255, 255, 255, 0.3)";
}
